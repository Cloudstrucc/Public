```mermaid
graph TD;
style A fill:#1E90FF,stroke:#333,stroke-width:2px;
style B fill:#808080,stroke:#333,stroke-width:2px;
style C fill:#1E90FF,stroke:#333,stroke-width:2px;
style D fill:#808080,stroke:#333,stroke-width:2px;
style E fill:#1E90FF,stroke:#333,stroke-width:2px;
style F fill:#808080,stroke:#333,stroke-width:2px;
style G fill:#1E90FF,stroke:#333,stroke-width:2px;
style H fill:#808080,stroke:#333,stroke-width:2px;
style I fill:#1E90FF,stroke:#333,stroke-width:2px;
style J fill:#808080,stroke:#333,stroke-width:2px;
A[Microsoft Azure AD & Power Apps Portal] --> B[User Identity Mapping];
B --> C[Blockchain Network];
C --> D[Smart Contracts];
D --> E[Document Metadata and Hashing];
E --> F[Recording Changes on Blockchain];
F --> G[Immutability and Security];
G --> H[Access Control];
H --> I[Optional Crypto Tokens];
I --> J[Reporting and Visualization];
```
