
```mermaid
graph TB
    A["User Identity: Use Microsoft's Entra Verified ID"]
    B["User Actions Tracking: Capture actions as events"]
    C["Event Recording on Blockchain: Create blockchain transaction for each event"]
    D["Auditing and Compliance: Provide verifiable record of all actions"]
    A --> B
    B --> C
    C --> D
```
