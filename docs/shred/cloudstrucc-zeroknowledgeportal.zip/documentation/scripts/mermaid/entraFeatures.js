```mermaid
graph TB
    A["Decentralized Identifiers (DIDs)"]
    B["ION (Identity Overlay Network)"]
    C["Verifiable Credentials"]
    D["Entra Verified ID Service"]
    E["Users"]
    F["Trust System"]
    G["ION"]
    H["DID:Web"]
    I["Roles in a Verifiable Credential Environment"]
    J["(e.g., Employer - Issuer)"]
    K["(e.g., Employee - User)"]
    L["(e.g., Vendor - Verifier)"]
    M["DPKI (Decentralized Public Key Infrastructure)"]
    N["Issuer's Public Key"]
    
    A --> B
    A --> C
    D --> C
    D --> E
    F --> G
    F --> H
    I --> J
    I --> K
    I --> L
    J --> K
    K --> L
    L --> M
    M --> N
```