### **Brainstorming / Flow of Implementations** 



![Mermaid Diagram](images/mermaid/brainstorming.png)



1.  **Microsoft Azure AD and Microsoft Power Apps Portal:**

    Microsoft Azure AD and Microsoft Power Apps Portal for user
    authentication and as the front-end interface for the CRM system.

2.  **Blockchain Network:**

    Ethereum, Hedera, Hyperledger Fabric, or Binance Smart Chain.

3.  **Smart Contracts:**

    Create smart contracts (also known as chaincode or solidity
    contracts) on the chosen blockchain platform to manage the
    document change tracking process. Smart contracts are
    self-executing contracts with predefined rules and logic that
    facilitate secure interactions on the blockchain.

4.  **User Identity Mapping:**
    
    Establish a mapping system between the users\' Microsoft Azure AD identities and their corresponding blockchain addresses. This ensures that user actions on the blockchain can be tied back to their real-world identities.

5.  **Document Metadata and Hashing:**
    
    For each document uploaded or edited on the portal, extract
    relevant metadata (e.g., document name, version, timestamp, user ID) and generate a cryptographic hash of the document content. The hash will act as a unique identifier for each version of the document.

6.  **Recording Changes on the Blockchain:**
    
    When a user makes changes to a document, the smart contract should be invoked to record the change. The smart contract will store the metadata, the hash of the modified document, and the user\'s blockchain address on the blockchain.

7.  **Immutability and Security:**
    
    Once a change is recorded on the blockchain, it becomes immutable, meaning it cannot be altered or deleted. This ensures a transparent and tamper-proof audit trail of document changes.

8.  **Access Control:**
    Implement access controls on the blockchain smart contract to
    ensure that only authorized users can interact with the document change tracking system.

9.  **Crypto Tokens:**
    Optionally, you can introduce a custom crypto token to incentivize users for participating in the blockchain network. For example, users might receive tokens for making valuable contributions to the system or for maintaining a high level of integrity in their document changes. (Not applicable but can incentivize government workers for quality of work, number of documents pushed out via bonuses)

10. **Reporting and Visualization:**
    
    Develop a reporting and visualization module within the Power Apps Portal to allow government officials to view the history of document changes, associated users, and timestamps. This provides transparency and enhances the system\'s trustworthiness



### **Microsoft Entra ID Features:** 


![Mermaid Diagram](images/mermaid/entraFeatures.png)


1.  Decentralized Identifiers (DIDs): These are user-generated, globally unique identifiers rooted in decentralized systems like ION (Identity Overlay Network). They are self-owned and provide
greater assurance of immutability, censorship resistance, and
tamper evasiveness.

2.  Verifiable Credentials: These are data objects consisting of claims  made by the issuer attesting information about a subject. These claims include the DID issuer and subject. The issuer\'s DID
    creates a digital signature as proof that they attest to this
    information.

3.  Entra Verified ID Service: This is an issuance and verification
    service in Azure. It\'s a REST API for W3C Verifiable Credentials that are signed with the did:web or the did:ion method. It enables identity owners to generate, present, and verify claims, forming the basis of trust between users of the system.

4.  Trust System: Microsoft currently supports two trust systems - ION Identity Overlay Network) and DID:Web. ION is an open,
    permissionless network based on the Sidetree protocol, which
    requires no special tokens, trusted validators, or other consensus mechanisms, while DID:Web allows trust using a web domain's existing reputation.

5.  Roles in a Verifiable Credential Environment: There are three
    primary actors in the verifiable credential solution - the issuer, the user, and the verifier.

    a.  The issuer (for example, an employer) verifies a user\'s
        identity and issues a verifiable credential signed with their DID.

    b.  The user (for example, an employee) requests a verifiable
        credential and presents it when necessary (for example, to get
        a discount at a specific vendor).

    c.  The verifier (for example, a vendor offering discounts to
        specific employees) validates the credential by matching it against the public key placed in the DPKI (Decentralized
        Public Key Infrastructure).

### **Entra Verified ID Implementation**


![Mermaid Diagram](images/mermaid/entraImplementation.png)

1.  User Identity: Use Microsoft\'s Entra Verified ID to establish the identity of each user on the platform. This means that when a user signs in, they would provide verifiable credentials, which would be validated against their Decentralized Identifier (DID).

2.  User Actions Tracking: Every time a user performs an action on the CRM platform (like creating, updating, or deleting records),
    capture these actions as events. Each event should include
   necessary details such as user DID, timestamp, nature of the
    action, and related record details.

3.  Event Recording on Blockchain: For each user action event, create a corresponding transaction on the blockchain. Blockchain\'s
    inherent immutability makes it ideal for tracking actions in a
    transparent, verifiable, and tamper-proof manner. The user DID
    associated with each transaction allows for clear identification of who made what changes.

4.  Auditing and Compliance: With the above system in place, you would have a verifiable record of all actions on the platform. When
    required, you can provide auditors with a way to examine the
    blockchain transactions, thereby meeting the government\'s
    requirements for transparency and accountability.

### **Why HyperLedger Fabric \> Hedera**

1.  Governance Model: Hedera Hashgraph has a council-based governance model with a limited set of pre-determined entities (leading organizations across different industries and geographies) who can validate transactions. On the other hand, Hyperledger Fabric, being permissioned, allows you to decide the participating entities in the network.

2.  Performance and Consensus Algorithm: Hedera Hashgraph employs the hashgraph consensus algorithm, which can theoretically handle
    thousands of transactions per second, making it faster and more scalable than many blockchains. Hyperledger Fabric uses a
    customizable consensus protocol depending on the requirements; it can use Solo, Kafka, or Raft. **(Appendix for more info)**

3.  Privacy and Confidentiality: Hyperledger Fabric has superior
    capabilities when it comes to privacy and confidentiality, thanks to its channels and private data collections features. These
    features let you ensure that only the parties involved in a
    transaction have access to it. In contrast, while Hedera also
    supports privacy to a certain extent, it may not provide the same level of granular control as Hyperledger Fabric.

4.  Smart Contracts: Hedera\'s smart contracts are written in Solidity (same as Ethereum), while Hyperledger Fabric\'s chaincode can be written in general-purpose languages like Go, JavaScript, and Java. This could impact the learning curve for the development team.

5.  Interoperability and Integration: If you plan to integrate the
    platform with existing enterprise systems, Hyperledger Fabric
    might offer a smoother integration experience due to its modular architecture and wide industry acceptance. Hedera, while growing, might not have the same level of enterprise system support.

6.  Community and Support: Both have strong community support.
    Hyperledger Fabric, being part of the Linux Foundation, has a
    broad open-source community. Hedera also has a good developer
    community, and its codebase is open for review.

7.  Transaction Costs: Hedera uses a model similar to Ethereum where you pay for transactions in cryptocurrency (HBAR for Hedera).
    Hyperledger Fabric, being a private and permissioned network, does not require a native cryptocurrency and there are no transaction fees.

### 

### 

### **Appendix**

Solo, Kafka, and Raft are consensus algorithms used in Hyperledger
Fabric to ensure all participants in a network agree on the order of
transactions. Here\'s a brief overview of each:

1.  Solo: This is the simplest consensus mechanism available and is
    primarily meant for development and testing purposes. It involves a single ordering node, which makes it easy to set up and run, but it provides no fault tolerance or scalability. If the ordering node fails, the network will stop functioning.

2.  Kafka: Kafka is a crash fault-tolerant consensus mechanism. It
     employs a message-oriented \"publish/subscribe\" model. This model provides an ordering service, ensuring all transactions are executed in the same order. The Kafka-based ordering service is distributed, meaning it runs on multiple nodes, thereby providing fault tolerance. However, it does not protect against Byzantine faults (where nodes can lie or send incorrect information).

3.  Raft: Raft is also a crash fault-tolerant consensus mechanism.
    Unlike Kafka, Raft follows a \"leader and follower\" model, where a leader node is elected among all the nodes in the network. All transaction ordering operations are done by the leader, and these are then replicated by the follower nodes. Raft is easier to manage and understand compared to Kafka and is capable of continued operation as long as more than half of the nodes are functioning properly.

The choice between Kafka and Raft (Solo is not recommended for
production due to its lack of fault tolerance) will depend on the
specific needs. Raft is generally simpler to set up and manage, while Kafka may provide slightly higher performance. However, both Kafka and Raft can be suitable for most enterprise-level applications.
